# @from-trees/ui

Native React + StyleX source package for From Trees applications. Components and tokens are compiled by the consuming app's shared StyleX setup.

```tsx
import {ThemeProvider, Button} from '@from-trees/ui';
import {color, metrics, space} from '@from-trees/ui/tokens.stylex';
```

Configure `fromTreesStylex` from `@from-trees/ui/vite` in Vite and Vitest. It compiles library and app source together and loads the compiler-generated stylesheet. There is no library CSS import or compiled distribution.

Themes: forest/slate/dark. Density: comfortable/compact. The application owns business logic and data. This package deliberately targets our React, TypeScript, StyleX and Vite stack.

https://from-trees.github.io/design-system/

Use the shared spacing/layout classes in applications:

```tsx
import {layout, gap, padding} from '@from-trees/ui/utilities';
<div {...stylex.props(layout.stack, gap.lg, padding.xl)}>…</div>
```

Spacing keys: none/xs/sm/md/lg/xl/xxl = 0/4/8/12/16/24/32 px. Gap, padding, margin and logical block/inline variants share the same tokens. Keep domain-specific and responsive styles local.

`List` owns standard title/metadata/status-or-menu rows. Supply item data and actions; do not rebuild the row in applications. See the catalog's Lists page and History & sharing workflow.

`InfoTooltip` provides optional non-interactive elaboration on hover, keyboard focus or tap. Parameters use it for reference/help details while validation remains inline. Review this behavior in the catalog before app adoption.

`Parameters` renders ordered app-defined groups and fields. Define the specific schema, grouping, order and units in an app wrapper, as the catalog's CabinetParameters does. The UI package provides no cabinet preset or default units.

`Slider` is a controlled native range input that composes with `ParameterRow` labels and contextual help. Applications supply `min`, `max`, `step`, `value`, `onChange` and optional `formatValue`; all units, formulas, persistence and authorization stay in the application. Arrow keys retain the supplied precision. `SidePanel size="wide-workflow"` provides a 1,100-pixel desktop editor capped at the viewport width, retaining the existing workflow panel's focus, dismissal and motion behavior. Review the synthetic `?example=estimate-profit` catalog composition before adoption.

`Slider valueInput={{ label, suffix }}` replaces its read-only output with a synchronized decimal text input, without increment buttons. The field reserves enough width to show a decimal value; the label, slider and field remain on one line using `ParameterRow layout="inline"`, which gives compound controls the space after the label. Bounds and increments come from the app's existing `min`, `max` and `step`; Enter or blur validates the draft entry and snaps it to that increment. Escape cancels the draft entry. Blank, nonfinite and out-of-range values remain invalid without changing the controlled value. `onValidityChange` reports both pending drafts and invalid entries so app save/progress controls can wait for a valid applied value. Both controls have unique IDs and retain the parent parameter's contextual help. Omit `valueInput` to preserve the read-only output contract.


### Workflow progress (0.8.0)

`WorkflowProgress` accepts app-defined `steps`, `selectedId`, `onSelect` and an accessible `label`. Steps provide `id`, `label`, `status`, `detail` and `available`. The app owns eligibility and completion. Navigation only changes the displayed stage; it does not sign, pay or advance production. See the Customer estimates catalog pattern before app adoption.

### Grouped workspace navigation (0.10.0 catalog review)

`WorkspaceLayout` supplies a grouped left navigation with independently scrolling navigation/content and a named navigation drawer at narrow container widths. `GroupedNavigation` and `Breadcrumbs` can also be used separately. All links retain real `href` values, accessible current-page state, keyboard activation and modified-click/new-tab behavior. Apps supply `NavigationGroup[]`, `activeId` and optionally `onNavigate`; the package does not parse or persist routes, authorize destinations, or load records.

```tsx
<WorkspaceLayout
  title={business.name}
  groups={authorizedGroups}
  activeId={route.pageId}
  onNavigate={({ href }) => router.navigate(href)}
>
  <Breadcrumbs items={route.breadcrumbs} onNavigate={navigate} />
  <RecordsPage />
</WorkspaceLayout>
```

Give the layout a bounded parent height for independent scrolling. The navigation opens in a drawer until the workspace container reaches 761px. Normal links work without a custom navigation callback. Do not turn application destinations into button rows or action menus.

Side panels cover the viewport at widths up to 640px. Panel bodies scroll independently of headers and footers. Use `SegmentedControl narrowBehavior="select"` for record sections that should switch to a native select at 420px of available space or less. Keep the same controlled value and options at both sizes. Tables keep their columns in a horizontal scroll area. At up to 540px of available space, the table expands vertically so the surrounding page can scroll to the pagination.

The workspace catalog example owns its synthetic routing model. Review refresh, copied/deep links, Back/Forward, list criteria, exact saved revisions, customer/contact/address identity and unavailable destinations there before application adoption. Existing Cabinitron customer editing/preparation, permissions, immutable snapshots and backend APIs remain application responsibilities.

### Grouped swatch choices (0.12.0 catalog review)

`SwatchPicker` accepts either the existing flat `options` or `groups` containing an `id`, visible `label`, and `options`. Both modes keep one controlled selection and display its preview in the field and popup. Group and option IDs must be unique throughout the picker. Applications supply all preview artwork, names, eligibility, saved choices and grouping; the UI package does not load material libraries or change finishes.

```tsx
<SwatchPicker
  value={materialId}
  onChange={setMaterialId}
  groups={[
    {id: 'built-in', label: 'Built-In', options: builtInChoices},
    {id: 'library', label: 'Library', options: libraryChoices},
  ]}
/>
```

Groups have accessible headings. Keyboard navigation, typeahead, disabled choices, Escape cancellation and focus restoration apply across groups. An entirely empty picker stays disabled; callers can supply a disabled descriptive option when a group needs an empty-state message. Review the grouped material example in **Swatches & previews** before application adoption. The catalog uses illustrative wood/paint/library samples; it has no business data, pricing, sheen control or persistence migration.

Text table columns may provide `thumbnail: item => ({src, loading, fit})` to show
48px decorative artwork next to their label and metadata. `fit` defaults to
`contain`; use `cover` for surface samples. `loading: true` shows the existing
Shimmer while an application prepares an image (for example a rendered model).
Image downloads also shimmer until load/error. Missing or failed images fall back
to an icon. Names, sorting, row keyboard navigation and actions are unchanged;
applications retain responsibility for asset authorization and model rendering.

Text table columns may supply `inlineAction: item => ({label, icon, onAction,
disabled})` (or `null`) for a contextual icon button beside the cell label.
Use a specific accessible label, such as `Filter by customer ${item.customer}`.
The button supports pointer and keyboard activation independently of row opening.
Applications own query updates, navigation and authorization. For filter shortcuts,
preserve other query fields and filters, replace the relevant filter, and reset
`page` to 1. See the catalog's Tables customer shortcut for an example.

Use a column with `kind: "action"` for a compact, directly available icon button.
Its `value(item)` supplies the button label, icon, and action. Place it before
the data columns to make the action easier to reach. The first data column
remains the row heading. Activating the icon runs the supplied action separately
from the row action.

Text columns may opt into `fillWidth: true` to use the available horizontal column width while remaining on one line. Values truncate with ellipsis only at the column edge. Other columns retain their compact width cap. Metadata keeps its existing compact presentation.

`Dialog`, `SidePanel`, and `TaskHeader` accept optional `headerActions` for controls such as a contextual button with `icon="help"`. Applications supply the accessible name and behavior.
